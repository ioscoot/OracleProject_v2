/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServletPackage;

/**
 *
 * @author user
 */
public class UserBean {

    public UserBean() {
        this.nume=null;
        this.e_mail=null;
        this.parola=null;
        this.type_id=0;
        this.valid=false;
    }
    public String nume;
    public String e_mail;
    public String parola;
    public int type_id;
    public boolean valid;

    
    
    public void setNume(String nume) {
       this.nume=nume;
    }

    public void setE_mail(String e_mail) {
        this.e_mail = e_mail;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }

    public void setType_id(int type_id) {
        this.type_id = type_id;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public String getNume() {
        return nume;
    }

    public String getE_mail() {
        return e_mail;
    }

    public String getParola() {
        return parola;
    }

    public int getType_id() {
        return type_id;
    }

    public boolean isValid() {
        return valid;
    }
    
}
