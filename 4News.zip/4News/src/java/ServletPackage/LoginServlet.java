/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServletPackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author user
 */
public class LoginServlet extends HttpServlet {
    Connection connection=null;
String user=null;
String password=null;


   public void init(){
       try {
           Class.forName("oracle.jdbc.driver.OracleDriver");
            connection=DriverManager.getConnection("jdbc:oracle:thin:@37.120.250.20:1521:oracle","tudorachep_44","stud");
           Statement st=connection.createStatement();
          
           
       } 
       catch (ClassNotFoundException ex) {
           Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
       } catch (SQLException ex) {
           Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
   
   public void service(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException
   {
       try{
           user=request.getParameter("uname");
           password=request.getParameter("psw");
           String query="select * from users where nume='"+user+"'";
           Statement st=connection.createStatement();
           ResultSet rs=st.executeQuery(query);
           
           
           String us=null;
           String pass=null;
           while(rs.next()){
               us=rs.getString("NUME");
               pass=rs.getString("PAROLA");
              
           }
               if( user.equals(us) && password.equals(pass) ){
               response.sendRedirect("index.jsp");
               }
               else{
               response.sendRedirect("login.jsp");
           }
           
           
       }
       catch(Exception e){
           e.printStackTrace();
       }
   }

}
